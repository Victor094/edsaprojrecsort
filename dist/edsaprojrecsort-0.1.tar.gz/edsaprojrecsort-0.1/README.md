# edsaprojrecsort
This library was create as an example of how to publish you own python packages

## building this package locally
'python setup.py sdist'

## installing this package from github
'pip install git +'https://github.com/Victor094/edsaprojrecsort.git

## update this package from github
'pip install --upgrade git+'https://github.com/Victor094/edsaprojrecsort.git
